﻿using Asp.netCoreMVCCRUD.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asp.netCoreMVCCRUD.Repository
{
    public class WeatherRepository : IWeatherRepository
    {
        private WeatherContext _context;
        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if(!this.disposed)
            {
                if(disposing)
                {
                    _context.Dispose();
                }
            }
            this.disposed = true;
        }

        public WeatherRepository(WeatherContext weatherContext)
        {
            this._context = weatherContext;
        }
        
        public void CreateWeatherReport(Weather weather)
        {
             _context.WeatherRanges.Add(weather);
        }

        public void DeleteWeatherReport(int ID)
        {
            Weather weather = _context.WeatherRanges.Find(ID);
            _context.WeatherRanges.Remove(weather);
        }

        public Weather FindWeatherReport(int ID)
        {
            return _context.WeatherRanges.Find(ID);
        }
        //
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public IEnumerable<Weather> GetWeathersReport()
        {
            return _context.WeatherRanges;
        }

        public void UpdateWeatherReport(Weather weather)
        {
            _context.Entry(weather).State = EntityState.Modified;
        }
        public void Save()
        {
            _context.SaveChanges();
        }
    }
}
