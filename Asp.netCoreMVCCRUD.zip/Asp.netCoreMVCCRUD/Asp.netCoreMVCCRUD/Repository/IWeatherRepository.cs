﻿using Asp.netCoreMVCCRUD.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Asp.netCoreMVCCRUD.Repository
{
    public interface IWeatherRepository : IDisposable
    {
        IEnumerable<Weather> GetWeathersReport();
        void CreateWeatherReport(Weather weather);
        void UpdateWeatherReport(Weather weather);
        void DeleteWeatherReport(int ID);
        Weather FindWeatherReport(int ID);
        void Save();
    }
}
