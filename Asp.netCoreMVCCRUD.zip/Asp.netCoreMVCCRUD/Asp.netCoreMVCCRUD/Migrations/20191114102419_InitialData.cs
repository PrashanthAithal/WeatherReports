﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Asp.netCoreMVCCRUD.Migrations
{
    public partial class InitialData : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "WeatherRanges",
                columns: table => new
                {
                    ID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Min = table.Column<string>(type: "varchar(10)", nullable: false),
                    Max = table.Column<string>(type: "varchar(10)", nullable: false),
                    Adjective = table.Column<string>(type: "varchar(100)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WeatherRanges", x => x.ID);
                });

            migrationBuilder.InsertData(
                table: "WeatherRanges",
                columns: new[] { "ID", "Adjective", "Max", "Min" },
                values: new object[,]
                {
                    { 1, "Average Temparature", "30", "20" },
                    { 2, "Coolest Temparature", "7", "-8" },
                    { 3, "Cool Temparature", "18", "4" },
                    { 4, "Hotter Temparature", "35", "21" },
                    { 5, "Hottest Temparature", "42", "28" }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "WeatherRanges");
        }
    }
}
