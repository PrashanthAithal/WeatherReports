﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Asp.netCoreMVCCRUD.Models;
using Asp.netCoreMVCCRUD.Repository;
using System.Data;

namespace Asp.netCoreMVCCRUD.Controllers
{
    public class WeatherController : Controller
    {
        private IWeatherRepository _weatherRepository;

        public WeatherController()
        {
            this._weatherRepository = new WeatherRepository(new WeatherContext());
        }

        // GET: Employee
        public ActionResult Index()
        {
            var weather = from w in _weatherRepository.GetWeathersReport() select w;
            return View(weather);
        }


        // GET: Employee/Create
        public IActionResult AddOrEdit(int id = 0)
        {
            if (id == 0)
                return View(new Weather());
            else
                return View(_weatherRepository.FindWeatherReport(id));
        }

        // POST: Employee/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddOrEdit([Bind("ID,Min,Max,Adjective")] Weather weather)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (weather.ID == 0)
                        _weatherRepository.CreateWeatherReport(weather);
                    else
                        _weatherRepository.UpdateWeatherReport(weather);
                    _weatherRepository.Save();
                    return RedirectToAction(nameof(Index));
                }
            }
            catch (DataException)
            {
                ModelState.AddModelError("Exception","Unable to Save changes. Please try again.");
            }
            
            return View(weather);
        }


        
        public ActionResult Delete(int id)
        {
            try
            {
                _weatherRepository.DeleteWeatherReport(id);
            }
            catch (DataException)
            {
                ModelState.AddModelError("Exception", "Unable to delete. Please try again.");
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
