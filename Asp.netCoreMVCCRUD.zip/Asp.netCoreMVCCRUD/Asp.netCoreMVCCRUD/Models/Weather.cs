﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Asp.netCoreMVCCRUD.Models
{
    public class Weather
    {
        [Key]
        public int ID { get; set; }

        [Column(TypeName = "varchar(10)")]
        [Required(ErrorMessage = "This field is required.")]
        [DisplayName("Min Temparature")]
        public string Min { get; set; }

        [Column(TypeName = "varchar(10)")]
        [Required(ErrorMessage = "This field is required.")]
        [DisplayName("Max Temperature")]
        public string Max { get; set; }

        [Column(TypeName = "varchar(100)")]
        [Required(ErrorMessage = "This field is required.")]
        public string Adjective { get; set; }
    }
}
