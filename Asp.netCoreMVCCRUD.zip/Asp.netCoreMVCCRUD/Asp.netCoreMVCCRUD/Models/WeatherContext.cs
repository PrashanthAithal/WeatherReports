﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace Asp.netCoreMVCCRUD.Models
{
    public class WeatherContext: DbContext
    {
        public WeatherContext(DbContextOptions<WeatherContext> options) : base(options)
        {

        }
        public WeatherContext(DbContextOptions options) : base(options)
        {

        }
        public WeatherContext()
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
           if(!optionsBuilder.IsConfigured)
            {
                IConfigurationRoot configRoot = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json").Build();
                var connsectionString = configRoot.GetConnectionString("DevConnection");
                optionsBuilder.UseSqlServer(connsectionString);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Weather>().HasData(new Weather { ID = 1, Min = "20", Max = "30", Adjective = "Average Temparature" });
            modelBuilder.Entity<Weather>().HasData(new Weather { ID = 2, Min = "-8", Max = "7", Adjective = "Coolest Temparature" });
            modelBuilder.Entity<Weather>().HasData(new Weather { ID = 3, Min = "4", Max = "18", Adjective = "Cool Temparature" });
            modelBuilder.Entity<Weather>().HasData(new Weather { ID = 4, Min = "21", Max = "35", Adjective = "Hotter Temparature" });
            modelBuilder.Entity<Weather>().HasData(new Weather { ID = 5, Min = "28", Max = "42", Adjective = "Hottest Temparature" });
        }
        public DbSet<Weather> WeatherRanges { get; set; }
    }
}
